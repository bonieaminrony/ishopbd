var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var admin = __toESM(require("firebase-admin"), 1);
var import_firestore = require("firebase-admin/firestore");
var import_auth = require("firebase-admin/auth");
var import_path = __toESM(require("path"), 1);
var import_fs = __toESM(require("fs"), 1);
var import_nodemailer = __toESM(require("nodemailer"), 1);
var import_dotenv = __toESM(require("dotenv"), 1);
var import_axios = __toESM(require("axios"), 1);
var import_genai = require("@google/genai");
var import_compression = __toESM(require("compression"), 1);
var import_crypto = __toESM(require("crypto"), 1);
import_dotenv.default.config();
if (process.argv[1] && process.argv[1].endsWith("server.cjs")) {
  process.env.NODE_ENV = "production";
}
var requiredEnvs = ["GEMINI_API_KEY"];
var missingEnvs = requiredEnvs.filter((key) => !process.env[key]);
if (missingEnvs.length > 0) {
  console.warn(`[WARNING] Missing recommended environment variables: ${missingEnvs.join(", ")}`);
  console.warn("Some features like AI Chat may not work properly.");
}
if (!process.env.EMAIL_USER || !process.env.EMAIL_PASS) {
  console.warn("[WARNING] EMAIL_USER or EMAIL_PASS not set. Order confirmation emails will not be sent.");
}
var MASTER_ADMIN_PASSWORD = process.env.MASTER_ADMIN_PASSWORD || "islamic786";
if (!process.env.MASTER_ADMIN_PASSWORD) {
  console.warn("[WARNING] MASTER_ADMIN_PASSWORD is not set in .env. Using code fallback password.");
}
var adminFailMap = /* @__PURE__ */ new Map();
function checkAdminBruteForce(ip) {
  const MAX_ATTEMPTS = 5;
  const LOCKOUT_MS = 15 * 60 * 1e3;
  const now = Date.now();
  const entry = adminFailMap.get(ip);
  if (entry && now < entry.lockedUntil) {
    return { allowed: false, lockedFor: Math.ceil((entry.lockedUntil - now) / 1e3) };
  }
  return { allowed: true };
}
function recordAdminFail(ip) {
  const MAX_ATTEMPTS = 5;
  const LOCKOUT_MS = 15 * 60 * 1e3;
  const now = Date.now();
  const entry = adminFailMap.get(ip) || { count: 0, lockedUntil: 0 };
  entry.count++;
  if (entry.count >= MAX_ATTEMPTS) {
    entry.lockedUntil = now + LOCKOUT_MS;
    entry.count = 0;
    console.warn(`[SECURITY] Admin login locked for IP: ${ip} for 15 minutes.`);
  }
  adminFailMap.set(ip, entry);
}
function clearAdminFail(ip) {
  adminFailMap.delete(ip);
}
var rateLimitMap = /* @__PURE__ */ new Map();
function rateLimit(ip, maxRequests, windowMs) {
  const now = Date.now();
  const entry = rateLimitMap.get(ip);
  if (!entry || now > entry.resetAt) {
    rateLimitMap.set(ip, { count: 1, resetAt: now + windowMs });
    return true;
  }
  entry.count++;
  return entry.count <= maxRequests;
}
setInterval(() => {
  const now = Date.now();
  for (const [key, val] of rateLimitMap.entries()) {
    if (now > val.resetAt) rateLimitMap.delete(key);
  }
}, 5 * 60 * 1e3);
var productCache = null;
var PRODUCT_CACHE_TTL_MS = 5 * 60 * 1e3;
async function getCachedProducts(db) {
  const now = Date.now();
  if (productCache && now < productCache.expiresAt) {
    return productCache.data;
  }
  try {
    const firestore = db || (0, import_firestore.getFirestore)();
    const snap = await firestore.collection("products").get();
    const products = snap.docs.map((d) => ({ id: d.id, ...d.data() })).filter((p) => !p.deleted);
    productCache = { data: products, expiresAt: now + PRODUCT_CACHE_TTL_MS };
    return products;
  } catch (e) {
    console.warn("getCachedProducts warning:", e.message);
    return productCache?.data || [];
  }
}
function invalidateProductCache() {
  productCache = null;
}
function slugify(text, maxLen = 38) {
  if (!text) return "";
  let s = text.toString().trim().replace(/&/g, " and ").replace(/\+/g, " plus ").replace(/@/g, " at ").replace(/(\d)\.(\d)/g, "$1-$2").toLowerCase().replace(/[^\w\s\u0980-\u09FF-]/g, "").replace(/[\s_–—-]+/g, "-").replace(/^-+|-+$/g, "");
  if (s.length > maxLen) {
    const cut = s.substring(0, maxLen);
    const lastHyphen = cut.lastIndexOf("-");
    s = (lastHyphen > 10 ? cut.substring(0, lastHyphen) : cut).replace(/-+$/, "");
  }
  return s;
}
function getProductSlug(product) {
  if (!product) return "";
  if (product.slug && typeof product.slug === "string" && product.slug.trim()) {
    const custom = slugify(product.slug.trim(), 50);
    if (custom) return custom;
  }
  if (product.smsName && typeof product.smsName === "string" && product.smsName.trim().length >= 3) {
    const smsSlug = slugify(product.smsName.trim(), 35);
    const prodId2 = product.id ? String(product.id).trim() : "";
    if (smsSlug) {
      if (prodId2 && !smsSlug.includes(prodId2.toLowerCase())) {
        const shortId = prodId2.length > 8 ? prodId2.slice(-6) : prodId2;
        return `${smsSlug}-${shortId}`;
      }
      return smsSlug;
    }
  }
  const rawName = product.name || product.title || "";
  const nameSlug = slugify(rawName, 35);
  const prodId = product.id ? String(product.id).trim() : "";
  if (nameSlug && prodId) {
    if (nameSlug.endsWith(prodId.toLowerCase())) {
      return nameSlug;
    }
    const shortId = prodId.length > 8 ? prodId.slice(-6) : prodId;
    return `${nameSlug}-${shortId}`;
  }
  return nameSlug || prodId || "";
}
var serviceAccountPath = import_path.default.join(process.cwd(), "api", "service-account.json");
if (!import_fs.default.existsSync(serviceAccountPath)) {
  serviceAccountPath = import_path.default.join(process.cwd(), "public", "api", "service-account.json");
}
if (import_fs.default.existsSync(serviceAccountPath)) {
  try {
    admin.initializeApp({
      credential: admin.cert(JSON.parse(import_fs.default.readFileSync(serviceAccountPath, "utf8"))),
      databaseURL: "https://i-shop-bd.firebaseio.com"
    });
    console.log("Firebase Admin initialized successfully.");
  } catch (e) {
    if (!/already exists/.test(e.message)) {
      console.error("Firebase Admin init error:", e);
    }
  }
} else {
  console.error("[CRITICAL] service-account.json not found. Backend checkout won't work.");
}
async function startServer() {
  const app = (0, import_express.default)();
  const PORT = Number(process.env.PORT) || 3e3;
  app.set("trust proxy", 1);
  app.use((0, import_compression.default)());
  app.use("/uploads", import_express.default.static(import_path.default.join(process.cwd(), "public", "uploads"), { maxAge: "30d" }));
  app.use("/api/chat", import_express.default.json({ limit: "32kb" }));
  app.use("/api/ai-recommendations", import_express.default.json({ limit: "32kb" }));
  app.use("/api/send-push", import_express.default.json({ limit: "16kb" }));
  app.use("/api/send-sms", import_express.default.json({ limit: "8kb" }));
  app.use("/api/send-bulk-sms", import_express.default.json({ limit: "256kb" }));
  app.use("/api/confirm-order", import_express.default.json({ limit: "64kb" }));
  app.use("/api/courier", import_express.default.json({ limit: "512kb" }));
  app.use(import_express.default.json({ limit: "50mb" }));
  app.use(import_express.default.urlencoded({ limit: "1mb", extended: true }));
  const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS || "").split(",").map((o) => o.trim()).filter(Boolean);
  app.use((req, res, next) => {
    const origin = req.headers.origin;
    const isAllowed = process.env.NODE_ENV !== "production" || // Allow all in dev
    !origin || // Same-origin requests
    ALLOWED_ORIGINS.includes(origin);
    if (isAllowed && origin) {
      res.setHeader("Access-Control-Allow-Origin", origin);
      res.setHeader("Access-Control-Allow-Methods", "GET,POST,OPTIONS");
      res.setHeader("Access-Control-Allow-Headers", "Content-Type,Authorization,X-Api-Key,X-Secret-Key");
      res.setHeader("Access-Control-Allow-Credentials", "true");
    }
    if (req.method === "OPTIONS") {
      return res.sendStatus(204);
    }
    next();
  });
  app.use((req, res, next) => {
    res.setHeader("X-Content-Type-Options", "nosniff");
    const ua = req.headers["user-agent"] || "";
    const isFacebook = /facebook|FBAN|FBIOS|FB_IAB|FB4A|facebookexternalhit/i.test(ua);
    if (!isFacebook) {
      res.setHeader("X-Frame-Options", "SAMEORIGIN");
    }
    res.setHeader("X-XSS-Protection", "1; mode=block");
    res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
    if (process.env.NODE_ENV === "production") {
      res.setHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
    }
    res.removeHeader("X-Powered-By");
    next();
  });
  app.use("/api", (req, res, next) => {
    const rawIp = req.headers["cf-connecting-ip"] || req.headers["x-forwarded-for"] || req.ip || req.socket.remoteAddress || "unknown";
    const ip = Array.isArray(rawIp) ? rawIp[0] : typeof rawIp === "string" ? rawIp.split(",")[0].trim() : rawIp;
    if (!rateLimit(ip + ":api", 300, 6e4)) {
      return res.status(429).json({ error: "Too many requests. Please wait a moment." });
    }
    next();
  });
  const transporter = import_nodemailer.default.createTransport({
    service: "gmail",
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS
    }
  });
  app.use("/__/auth", async (req, res) => {
    try {
      const targetUrl = `https://i-shop-bd.firebaseapp.com/__/auth${req.url}`;
      const response = await (0, import_axios.default)({
        method: req.method,
        url: targetUrl,
        headers: {
          ...req.headers,
          host: "i-shop-bd.firebaseapp.com",
          origin: "https://i-shop-bd.firebaseapp.com"
        },
        data: req.body,
        responseType: "arraybuffer",
        validateStatus: () => true
      });
      res.status(response.status);
      Object.entries(response.headers).forEach(([k, v]) => {
        if (v && k.toLowerCase() !== "transfer-encoding" && k.toLowerCase() !== "content-encoding") {
          res.setHeader(k, v);
        }
      });
      res.send(response.data);
    } catch (e) {
      console.warn("Auth proxy error:", e.message);
      res.status(500).send("Auth proxy error");
    }
  });
  app.get("/api/products", async (req, res) => {
    try {
      res.setHeader("Cache-Control", "public, max-age=30, stale-while-revalidate=120");
      const prods = await getCachedProducts();
      res.json(prods);
    } catch (e) {
      res.status(500).json({ error: "Failed to fetch products" });
    }
  });
  app.get("/api/banners", async (req, res) => {
    try {
      res.setHeader("Cache-Control", "public, max-age=30, stale-while-revalidate=120");
      const firestore = (0, import_firestore.getFirestore)();
      const snap = await firestore.collection("banners").get();
      const banners = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
      res.json(banners);
    } catch (e) {
      res.status(500).json({ error: "Failed to fetch banners" });
    }
  });
  app.get("/api/categories", async (req, res) => {
    try {
      res.setHeader("Cache-Control", "public, max-age=30, stale-while-revalidate=120");
      const firestore = (0, import_firestore.getFirestore)();
      const snap = await firestore.collection("categories").get();
      const categories = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
      res.json(categories);
    } catch (e) {
      res.status(500).json({ error: "Failed to fetch categories" });
    }
  });
  app.post("/api/verify-admin", (req, res) => {
    const rawIp = req.headers["cf-connecting-ip"] || req.headers["x-forwarded-for"] || req.ip || req.socket.remoteAddress || "unknown";
    const ip = Array.isArray(rawIp) ? rawIp[0] : typeof rawIp === "string" ? rawIp.split(",")[0].trim() : rawIp;
    const bf = checkAdminBruteForce(ip);
    if (!bf.allowed) {
      return res.status(429).json({
        success: false,
        error: `Too many failed attempts. Try again in ${bf.lockedFor} seconds.`
      });
    }
    const masterPassword = MASTER_ADMIN_PASSWORD;
    const { password } = req.body;
    if (typeof password !== "string" || password.length === 0 || password.length > 200) {
      return res.status(400).json({ success: false, error: "Invalid password format." });
    }
    if (password.trim() === masterPassword.trim()) {
      console.log(`[${(/* @__PURE__ */ new Date()).toISOString()}] Admin login SUCCESS from IP: ${ip}`);
      clearAdminFail(ip);
      return res.json({ success: true });
    }
    console.warn(`[${(/* @__PURE__ */ new Date()).toISOString()}] Admin login FAILED from IP: ${ip}`);
    recordAdminFail(ip);
    return res.status(401).json({ success: false, error: "Incorrect password." });
  });
  app.post("/api/upload", async (req, res) => {
    try {
      const { image, filename } = req.body;
      if (!image || typeof image !== "string" || !image.startsWith("data:image/")) {
        return res.status(400).json({ error: "Invalid image format" });
      }
      const match = image.match(/^data:(image\/[a-zA-Z+.-]+);base64,(.+)$/);
      if (!match) {
        return res.status(400).json({ error: "Invalid base64 image data" });
      }
      const contentType = match[1];
      const base64Data = match[2];
      const buffer = Buffer.from(base64Data, "base64");
      const allowedMimeTypes = ["image/jpeg", "image/jpg", "image/png", "image/webp", "image/gif", "image/svg+xml"];
      if (!allowedMimeTypes.includes(contentType)) {
        return res.status(400).json({ error: "Only image files are allowed (JPEG, PNG, WEBP, GIF, SVG)" });
      }
      let ext = "jpg";
      if (contentType === "image/png") ext = "png";
      else if (contentType === "image/webp") ext = "webp";
      else if (contentType === "image/gif") ext = "gif";
      else if (contentType === "image/svg+xml") ext = "svg";
      const uploadsDir = import_path.default.join(process.cwd(), "public", "uploads");
      if (!import_fs.default.existsSync(uploadsDir)) {
        import_fs.default.mkdirSync(uploadsDir, { recursive: true });
      }
      const sanitizedName = (filename || "image").replace(/[^a-zA-Z0-9.-]/g, "_").substring(0, 50);
      const uniqueFilename = `${Date.now()}-${Math.random().toString(36).substring(2, 8)}-${sanitizedName}.${ext}`;
      const filePath = import_path.default.join(uploadsDir, uniqueFilename);
      import_fs.default.writeFileSync(filePath, buffer);
      console.log(`Image uploaded successfully: /uploads/${uniqueFilename}`);
      return res.json({ url: `/uploads/${uniqueFilename}` });
    } catch (err) {
      console.error("Image upload error:", err);
      return res.status(500).json({ error: "Failed to upload image" });
    }
  });
  app.post("/api/send-sms", async (req, res) => {
    const rawIp = req.headers["cf-connecting-ip"] || req.headers["x-forwarded-for"] || req.ip || req.socket.remoteAddress || "unknown";
    const ip = Array.isArray(rawIp) ? rawIp[0] : typeof rawIp === "string" ? rawIp.split(",")[0].trim() : rawIp;
    if (!rateLimit(ip + ":sms", 5, 6e4)) {
      return res.status(429).json({ success: false, message: "Too many SMS requests. Please wait a moment." });
    }
    const { phone, message, senderId } = req.body;
    if (!phone || typeof phone !== "string") {
      return res.status(400).json({ success: false, message: "Phone number was not provided." });
    }
    if (!message || typeof message !== "string" || message.trim().length === 0) {
      return res.status(400).json({ success: false, message: "Message cannot be empty." });
    }
    if (message.length > 1e3) {
      return res.status(400).json({ success: false, message: "Message cannot exceed 1000 characters." });
    }
    const SMS_API_KEY = process.env.SMS_API_KEY;
    const SMS_SENDER_ID = senderId || process.env.SMS_SENDER_ID || "8809648908219";
    if (!SMS_API_KEY) {
      console.warn("SMS_API_KEY not set in environment. SMS not sent.");
      return res.status(200).json({ success: false, message: "SMS API key is not configured." });
    }
    let formattedPhone = String(phone || "").trim();
    const banglaToEnglish = { "\u09E6": "0", "\u09E7": "1", "\u09E8": "2", "\u09E9": "3", "\u09EA": "4", "\u09EB": "5", "\u09EC": "6", "\u09ED": "7", "\u09EE": "8", "\u09EF": "9" };
    formattedPhone = formattedPhone.replace(/[০-৯]/g, (match) => banglaToEnglish[match]);
    const isPlus = formattedPhone.startsWith("+");
    formattedPhone = formattedPhone.replace(/\D/g, "");
    if (isPlus) formattedPhone = "+" + formattedPhone;
    if (formattedPhone.startsWith("+")) {
      formattedPhone = formattedPhone.substring(1);
    }
    if (formattedPhone.startsWith("01") && formattedPhone.length === 11) {
      formattedPhone = "88" + formattedPhone;
    }
    try {
      const url = `https://bulksmsbd.net/api/smsapi`;
      const response = await import_axios.default.get(url, {
        params: {
          api_key: SMS_API_KEY,
          type: "text",
          number: formattedPhone,
          senderid: SMS_SENDER_ID,
          message
        }
      });
      const data = response.data;
      console.log("SMS API Response:", data);
      const isSuccess = data && (data.response_code === 202 || data.success_message && !data.error_message);
      res.json({
        success: isSuccess,
        message: isSuccess ? "SMS sent successfully" : data.error_message || "Failed to send SMS",
        data
      });
    } catch (error) {
      console.error("Error sending SMS:", error);
      res.status(500).json({ success: false, error: "Failed to send SMS due to server error" });
    }
  });
  app.post("/api/send-bulk-sms", async (req, res) => {
    const rawIp = req.headers["cf-connecting-ip"] || req.headers["x-forwarded-for"] || req.ip || req.socket.remoteAddress || "unknown";
    const ip = Array.isArray(rawIp) ? rawIp[0] : typeof rawIp === "string" ? rawIp.split(",")[0].trim() : rawIp;
    if (!rateLimit(ip + ":bulksms", 2, 6e4)) {
      return res.status(429).json({ success: false, message: "Too many requests. Please wait a moment." });
    }
    const { phones, message, senderId } = req.body;
    const SMS_API_KEY = process.env.SMS_API_KEY;
    const SMS_SENDER_ID = senderId || process.env.SMS_SENDER_ID || "8809648908219";
    if (!SMS_API_KEY) {
      return res.status(200).json({ success: false, message: "SMS API key is not configured." });
    }
    if (!phones || !Array.isArray(phones) || phones.length === 0) {
      return res.status(400).json({ success: false, message: "No phone numbers were provided." });
    }
    if (!message || message.trim().length === 0) {
      return res.status(400).json({ success: false, message: "Message cannot be empty." });
    }
    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");
    res.setHeader("X-Accel-Buffering", "no");
    res.flushHeaders();
    const sendEvent = (data) => {
      res.write(`data: ${JSON.stringify(data)}

`);
    };
    const formattedPhones = phones.map((phone) => {
      let p = String(phone || "").trim();
      const banglaToEnglish = { "\u09E6": "0", "\u09E7": "1", "\u09E8": "2", "\u09E9": "3", "\u09EA": "4", "\u09EB": "5", "\u09EC": "6", "\u09ED": "7", "\u09EE": "8", "\u09EF": "9" };
      p = p.replace(/[০-৯]/g, (match) => banglaToEnglish[match]);
      const isPlus = p.startsWith("+");
      p = p.replace(/\D/g, "");
      if (isPlus) p = "+" + p;
      if (p.startsWith("+")) p = p.substring(1);
      if (p.startsWith("01") && p.length === 11) p = "88" + p;
      return p;
    }).filter(Boolean);
    const BATCH_SIZE = 500;
    const totalBatches = Math.ceil(formattedPhones.length / BATCH_SIZE);
    let totalSuccess = 0;
    let totalFail = 0;
    sendEvent({ type: "start", total: formattedPhones.length, totalBatches });
    for (let i = 0; i < formattedPhones.length; i += BATCH_SIZE) {
      const batch = formattedPhones.slice(i, i + BATCH_SIZE);
      const batchNum = Math.floor(i / BATCH_SIZE) + 1;
      const numberStr = batch.join(",");
      sendEvent({ type: "progress", batchNum, totalBatches, batchSize: batch.length, sent: totalSuccess, failed: totalFail });
      try {
        const response = await import_axios.default.get("https://bulksmsbd.net/api/smsapi", {
          params: { api_key: SMS_API_KEY, type: "text", number: numberStr, senderid: SMS_SENDER_ID, message },
          timeout: 6e4
        });
        const data = response.data;
        const isSuccess = data && (data.response_code === 202 || data.success_message && !data.error_message);
        if (isSuccess) {
          totalSuccess += batch.length;
          sendEvent({ type: "batch_done", batchNum, success: true, count: batch.length, sent: totalSuccess, failed: totalFail });
        } else {
          totalFail += batch.length;
          sendEvent({ type: "batch_done", batchNum, success: false, count: batch.length, error: data.error_message || "API Error", sent: totalSuccess, failed: totalFail });
        }
      } catch (error) {
        totalFail += batch.length;
        sendEvent({ type: "batch_done", batchNum, success: false, count: batch.length, error: error.message, sent: totalSuccess, failed: totalFail });
        console.error(`Bulk SMS Batch ${batchNum} error:`, error.message);
      }
      if (i + BATCH_SIZE < formattedPhones.length) {
        await new Promise((resolve) => setTimeout(resolve, 800));
      }
    }
    sendEvent({ type: "done", successCount: totalSuccess, failCount: totalFail, total: formattedPhones.length });
    res.end();
  });
  app.get("/sitemap.xml", async (req, res) => {
    try {
      if (!admin.apps.length) return res.status(500).send("Firebase not initialized");
      const db = (0, import_firestore.getFirestore)();
      const [productsSnap, categoriesSnap, campaignsSnap] = await Promise.all([
        db.collection("products").where("deleted", "==", false).where("isPublished", "==", true).get(),
        db.collection("categories").get(),
        db.collection("campaigns").where("isActive", "==", true).get()
      ]);
      let xml = `<?xml version="1.0" encoding="UTF-8"?>
`;
      xml += `<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
`;
      xml += `  <url>
    <loc>https://rokomariponnohari.com/</loc>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>
`;
      categoriesSnap.forEach((doc) => {
        const name = doc.data().name || "";
        if (!name) return;
        const catSlug = (name || "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
        xml += `  <url>
    <loc>https://rokomariponnohari.com/category/${catSlug}</loc>
    <changefreq>daily</changefreq>
    <priority>0.9</priority>
  </url>
`;
      });
      campaignsSnap.forEach((doc) => {
        const slug = doc.data().slug || doc.id;
        xml += `  <url>
    <loc>https://rokomariponnohari.com/?campaign=${slug}</loc>
    <changefreq>weekly</changefreq>
    <priority>0.85</priority>
  </url>
`;
      });
      productsSnap.forEach((doc) => {
        const p = { id: doc.id, ...doc.data() };
        const slug = getProductSlug(p);
        const updatedAt = doc.data().updatedAt?.toDate?.()?.toISOString?.() || (/* @__PURE__ */ new Date()).toISOString();
        const prodPath = `/p/${slug}`;
        xml += `  <url>
    <loc>https://rokomariponnohari.com${prodPath}</loc>
    <lastmod>${updatedAt.split("T")[0]}</lastmod>
    <changefreq>daily</changefreq>
    <priority>0.8</priority>
  </url>
`;
      });
      xml += `</urlset>`;
      res.header("Content-Type", "application/xml");
      res.header("Cache-Control", "public, max-age=3600");
      res.send(xml);
    } catch (e) {
      res.status(500).send(e.message);
    }
  });
  app.post("/api/validate-coupon", async (req, res) => {
    const rawIp = req.headers["cf-connecting-ip"] || req.headers["x-forwarded-for"] || req.ip || req.socket.remoteAddress || "unknown";
    const ip = Array.isArray(rawIp) ? rawIp[0] : typeof rawIp === "string" ? rawIp.split(",")[0].trim() : rawIp;
    if (!rateLimit(ip + ":coupon", 10, 6e4)) {
      return res.status(429).json({ success: false, error: "Too many requests. Please wait." });
    }
    const { code, cartTotal, userId } = req.body;
    if (!code || typeof code !== "string") {
      return res.status(400).json({ success: false, error: "Invalid coupon code." });
    }
    if (typeof cartTotal !== "number" || cartTotal <= 0) {
      return res.status(400).json({ success: false, error: "Invalid cart total amount." });
    }
    if (!admin.apps.length) {
      return res.status(500).json({ success: false, error: "Server misconfiguration" });
    }
    try {
      const db = (0, import_firestore.getFirestore)();
      const couponRef = db.collection("coupons").doc(code.trim().toUpperCase());
      const couponSnap = await couponRef.get();
      if (!couponSnap.exists) {
        return res.status(404).json({ success: false, error: "This coupon code does not exist." });
      }
      const coupon = couponSnap.data();
      if (!coupon.isActive) {
        return res.status(400).json({ success: false, error: "This coupon is no longer active." });
      }
      if (coupon.expiresAt) {
        const expiresAt = coupon.expiresAt?.toDate ? coupon.expiresAt.toDate() : new Date(coupon.expiresAt);
        if (/* @__PURE__ */ new Date() > expiresAt) {
          return res.status(400).json({ success: false, error: "This coupon has expired." });
        }
      }
      if (coupon.minOrderAmount && cartTotal < coupon.minOrderAmount) {
        return res.status(400).json({
          success: false,
          error: `Minimum order of \u09F3${coupon.minOrderAmount} is required for this coupon.`
        });
      }
      if (coupon.usageLimit && (coupon.usedCount || 0) >= coupon.usageLimit) {
        return res.status(400).json({ success: false, error: "This coupon usage limit has been reached." });
      }
      if (userId && userId !== "guest" && coupon.perUserLimit) {
        const userUsageSnap = await db.collection("coupon_usage").where("couponCode", "==", code.trim().toUpperCase()).where("userId", "==", userId).get();
        if (userUsageSnap.size >= coupon.perUserLimit) {
          return res.status(400).json({ success: false, error: "You have already used this coupon." });
        }
      }
      let discountAmount = 0;
      let discountLabel = "";
      if (coupon.type === "percent") {
        discountAmount = Math.round(cartTotal * (coupon.value / 100));
        if (coupon.maxDiscount && discountAmount > coupon.maxDiscount) {
          discountAmount = coupon.maxDiscount;
        }
        discountLabel = `${coupon.value}% Off`;
      } else if (coupon.type === "fixed") {
        discountAmount = Math.min(coupon.value, cartTotal);
        discountLabel = `\u09F3${coupon.value} Off`;
      } else if (coupon.type === "free_delivery") {
        discountAmount = 0;
        discountLabel = "Free Delivery";
      }
      return res.json({
        success: true,
        coupon: {
          code: code.trim().toUpperCase(),
          type: coupon.type,
          value: coupon.value,
          discountAmount,
          discountLabel,
          description: coupon.description || discountLabel
        }
      });
    } catch (err) {
      console.error("Coupon validation error:", err);
      return res.status(500).json({ success: false, error: "Failed to validate coupon." });
    }
  });
  app.post("/api/create-order", async (req, res) => {
    const rawIp = req.headers["cf-connecting-ip"] || req.headers["x-forwarded-for"] || req.ip || req.socket.remoteAddress || "unknown";
    const ip = Array.isArray(rawIp) ? rawIp[0] : typeof rawIp === "string" ? rawIp.split(",")[0].trim() : rawIp;
    if (!rateLimit(ip + ":create-order", 10, 6e4)) {
      return res.status(429).json({ success: false, error: "Too many requests." });
    }
    const { newOrder, checkoutItems } = req.body;
    if (!newOrder || !checkoutItems || !Array.isArray(checkoutItems) || checkoutItems.length === 0) {
      return res.status(400).json({ success: false, error: "Invalid payload" });
    }
    if (!admin.apps.length) {
      return res.status(500).json({ success: false, error: "Server misconfiguration (Firebase Admin not initialized)" });
    }
    const db = (0, import_firestore.getFirestore)();
    let decodedToken = null;
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith("Bearer ")) {
      try {
        decodedToken = await (0, import_auth.getAuth)().verifyIdToken(authHeader.split("Bearer ")[1]);
      } catch (err) {
      }
    }
    if (newOrder.userId && newOrder.userId !== "guest") {
      if (!decodedToken || decodedToken.uid !== newOrder.userId) {
        return res.status(401).json({ success: false, error: "Unauthorized: Invalid user ID or token" });
      }
    }
    try {
      await db.runTransaction(async (transaction) => {
        const productRefs = {};
        const productDataMap = {};
        for (const item of checkoutItems) {
          const pId = item.product.id;
          if (!productRefs[pId]) {
            productRefs[pId] = db.collection("products").doc(pId);
          }
        }
        const refsArray = Object.values(productRefs);
        if (refsArray.length > 0) {
          const snaps = await transaction.getAll(...refsArray);
          snaps.forEach((snap) => {
            if (!snap.exists) throw new Error(`Product not found`);
            productDataMap[snap.id] = snap.data();
          });
        }
        const updatedProducts = {};
        for (const item of checkoutItems) {
          const pId = item.product.id;
          const pData = updatedProducts[pId] || productDataMap[pId];
          const iColor = item.color ? String(item.color).trim().toLowerCase() : null;
          const iSize = item.size ? String(item.size).trim().toLowerCase() : null;
          const reqQty = Number(item.quantity) || 1;
          if (reqQty <= 0) throw new Error("Invalid quantity");
          let currentVariants = [...pData.variants || []];
          let currentStock = Number(pData.stock || 0);
          let variantMatched = false;
          if (item.wholesaleSizeQty && Object.keys(item.wholesaleSizeQty).length > 0) {
            for (const [wSize, wQty] of Object.entries(item.wholesaleSizeQty)) {
              const qtyNum = Number(wQty);
              if (qtyNum < 0) throw new Error("Invalid quantity");
              if (qtyNum === 0) continue;
              const vIndex = currentVariants.findIndex((v) => (v.size ? String(v.size).trim().toLowerCase() : null) === wSize.trim().toLowerCase());
              if (vIndex > -1) {
                const vStock = Number(currentVariants[vIndex].stock || 0);
                if (vStock < qtyNum && !pData.isComingSoon) throw new Error(`Sorry, ${pData.name} is out of stock!`);
                currentVariants[vIndex].stock = vStock - qtyNum;
                variantMatched = true;
              }
            }
          } else {
            const vIndex = currentVariants.findIndex((v) => {
              const vColor = v.name ? String(v.name).trim().toLowerCase() : null;
              const vSize = v.size ? String(v.size).trim().toLowerCase() : null;
              if (iColor && iSize) return vColor === iColor && vSize === iSize;
              if (iColor) return vColor === iColor;
              if (iSize) return vSize === iSize;
              return false;
            });
            if (vIndex > -1) {
              const vStock = Number(currentVariants[vIndex].stock || 0);
              if (vStock < reqQty && !pData.isComingSoon) throw new Error(`Sorry, ${pData.name} is out of stock!`);
              currentVariants[vIndex].stock = vStock - reqQty;
              variantMatched = true;
            }
          }
          if (!variantMatched) {
            if (currentStock < reqQty && !pData.isComingSoon) throw new Error(`Sorry, ${pData.name} is out of stock!`);
            currentStock -= reqQty;
          }
          updatedProducts[pId] = { ...pData, variants: currentVariants, stock: currentStock };
        }
        for (const [pId, pData] of Object.entries(updatedProducts)) {
          transaction.update(productRefs[pId], {
            variants: pData.variants,
            stock: pData.stock,
            updatedAt: import_firestore.FieldValue.serverTimestamp()
          });
        }
        let userPoints = 0;
        if (newOrder.userId && newOrder.userId !== "guest") {
          const userSnap = await transaction.get(db.collection("users").doc(newOrder.userId));
          if (userSnap.exists) {
            userPoints = Number(userSnap.data().rewardPoints) || 0;
          }
        }
        let expectedSubtotal = 0;
        for (const item of checkoutItems) {
          const pId = item.product.id;
          const pData = productDataMap[pId];
          let reqQty = Number(item.quantity) || 1;
          if (reqQty <= 0) throw new Error("Invalid quantity");
          if (item.wholesaleSizeQty && Object.keys(item.wholesaleSizeQty).length > 0) {
            reqQty = 0;
            for (const wQty of Object.values(item.wholesaleSizeQty)) {
              reqQty += Number(wQty) || 0;
            }
          }
          let itemPrice = Number(pData.price) || 0;
          if (pData.wholesaleTiers && Array.isArray(pData.wholesaleTiers) && pData.wholesaleTiers.length > 0) {
            const sortedTiers = [...pData.wholesaleTiers].sort((a, b) => b.minQty - a.minQty);
            const tier = sortedTiers.find((t) => reqQty >= t.minQty);
            if (tier) itemPrice = Number(tier.price) || itemPrice;
          }
          expectedSubtotal += itemPrice * reqQty;
        }
        const clientTotal = Number(newOrder.total) || 0;
        const clientSubtotal = Number(newOrder.subtotal) || 0;
        const clientDelivery = Number(newOrder.deliveryCharge) || 0;
        const clientPoints = Number(newOrder.pointsDiscount) || 0;
        if (clientPoints > userPoints) throw new Error("You do not have enough reward points!");
        const clientDiscount = Number(newOrder.discount) || 0;
        if (Math.abs(clientSubtotal - expectedSubtotal) > 5) {
          console.error(`Subtotal mismatch! Client: ${clientSubtotal}, Server: ${expectedSubtotal}`);
          throw new Error("Order price mismatch. The order has been blocked for security reasons.");
        }
        const expectedTotalMath = clientSubtotal + clientDelivery - clientPoints - clientDiscount;
        if (Math.abs(clientTotal - expectedTotalMath) > 5) {
          console.error(`Total math mismatch! ClientTotal: ${clientTotal}, Math: ${expectedTotalMath}`);
          throw new Error("Total calculation discrepancy detected. The order has been blocked.");
        }
        const orderId = newOrder.orderId || newOrder.id || `ORD${Date.now()}`;
        delete newOrder.id;
        newOrder.createdAt = import_firestore.FieldValue.serverTimestamp();
        newOrder.status = "pending";
        if (newOrder.total < 0) throw new Error("Invalid total amount");
        transaction.set(db.collection("orders").doc(orderId), newOrder);
        if (newOrder.paymentMethod === "wallet" && newOrder.userId && newOrder.userId !== "guest") {
          const userRef = db.collection("users").doc(newOrder.userId);
          transaction.update(userRef, {
            balance: import_firestore.FieldValue.increment(-newOrder.total),
            updatedAt: import_firestore.FieldValue.serverTimestamp()
          });
        }
      });
      res.json({ success: true, message: "Order created successfully" });
    } catch (e) {
      console.error("Order creation error:", e);
      res.status(500).json({ success: false, error: e.message || "Failed to process order" });
    }
  });
  app.post("/api/confirm-order", async (req, res) => {
    const rawIp = req.headers["cf-connecting-ip"] || req.headers["x-forwarded-for"] || req.ip || req.socket.remoteAddress || "unknown";
    const ip = Array.isArray(rawIp) ? rawIp[0] : typeof rawIp === "string" ? rawIp.split(",")[0].trim() : rawIp;
    if (!rateLimit(ip + ":order", 10, 6e4)) {
      return res.status(429).json({ success: false, error: "Too many requests." });
    }
    const { customerName, customerPhone, items, total, address } = req.body;
    if (!customerName || typeof customerName !== "string" || customerName.trim().length === 0 || customerName.length > 200) {
      return res.status(400).json({ success: false, error: "Invalid customer name." });
    }
    if (!customerPhone || typeof customerPhone !== "string" || customerPhone.length > 20) {
      return res.status(400).json({ success: false, error: "Invalid phone number." });
    }
    if (!address || typeof address !== "string" || address.length > 1e3) {
      return res.status(400).json({ success: false, error: "Invalid address." });
    }
    if (!items || !Array.isArray(items) || items.length === 0 || items.length > 50) {
      return res.status(400).json({ success: false, error: "Invalid item list." });
    }
    if (typeof total !== "number" || total < 0 || total > 1e7) {
      return res.status(400).json({ success: false, error: "Invalid total quantity." });
    }
    const notifyEmail = process.env.ORDER_NOTIFY_EMAIL || process.env.EMAIL_USER;
    const itemRowsHtml = items.map((item) => {
      const name = typeof item?.product?.name === "string" ? item.product.name.substring(0, 200) : "Unknown Product";
      const qty = typeof item?.quantity === "number" ? item.quantity : "?";
      const price = typeof item?.product?.price === "number" ? item.product.price : 0;
      const subtotal = typeof qty === "number" ? price * qty : 0;
      return `
        <tr>
          <td style="padding:10px 12px;border-bottom:1px solid #f0f0f0;font-size:14px;color:#333;">${name}</td>
          <td style="padding:10px 12px;border-bottom:1px solid #f0f0f0;text-align:center;font-size:14px;color:#555;">${qty}</td>
          <td style="padding:10px 12px;border-bottom:1px solid #f0f0f0;text-align:right;font-size:14px;color:#333;">\u09F3${price.toLocaleString()}</td>
          <td style="padding:10px 12px;border-bottom:1px solid #f0f0f0;text-align:right;font-size:14px;font-weight:bold;color:#e07b39;">\u09F3${subtotal.toLocaleString()}</td>
        </tr>`;
    }).join("");
    const itemsPlainText = items.map((item) => {
      const name = typeof item?.product?.name === "string" ? item.product.name.substring(0, 200) : "Unknown";
      const qty = typeof item?.quantity === "number" ? item.quantity : "?";
      return `- ${name} (Qty: ${qty})`;
    }).join("\n");
    const orderDate = (/* @__PURE__ */ new Date()).toLocaleString("bn-BD", { timeZone: "Asia/Dhaka", dateStyle: "full", timeStyle: "short" });
    const htmlBody = `<!DOCTYPE html>
<html lang="bn">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"></head>
<body style="margin:0;padding:0;background:#f5f5f5;font-family:Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f5f5f5;padding:30px 0;">
    <tr><td align="center">
      <table width="600" cellpadding="0" cellspacing="0" style="background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,0.08);max-width:600px;width:100%;">
        
        <!-- Header -->
        <tr><td style="background:linear-gradient(135deg,#e07b39,#c9612a);padding:30px 40px;text-align:center;">
          <h1 style="margin:0;color:#fff;font-size:26px;font-weight:bold;">\u{1F6D2} i SHOP BD</h1>
          <p style="margin:8px 0 0;color:rgba(255,255,255,0.85);font-size:14px;">New Order Received!</p>
        </td></tr>

        <!-- Order Badge -->
        <tr><td style="padding:24px 40px 0;text-align:center;">
          <span style="display:inline-block;background:#fff3e8;color:#e07b39;border:2px solid #e07b39;border-radius:30px;padding:8px 24px;font-size:14px;font-weight:bold;">
            \u2705 Order Confirmed
          </span>
          <p style="color:#888;font-size:13px;margin:10px 0 0;">${orderDate}</p>
        </td></tr>

        <!-- Customer Info -->
        <tr><td style="padding:24px 40px;">
          <h2 style="margin:0 0 16px;font-size:16px;color:#333;border-bottom:2px solid #f0f0f0;padding-bottom:10px;">\u{1F4CB} Customer Details</h2>
          <table width="100%" cellpadding="0" cellspacing="0">
            <tr>
              <td style="padding:6px 0;color:#888;font-size:13px;width:120px;">Name:</td>
              <td style="padding:6px 0;color:#333;font-size:14px;font-weight:bold;">${customerName}</td>
            </tr>
            <tr>
              <td style="padding:6px 0;color:#888;font-size:13px;">Phone:</td>
              <td style="padding:6px 0;color:#333;font-size:14px;">${customerPhone}</td>
            </tr>
            <tr>
              <td style="padding:6px 0;color:#888;font-size:13px;">Address:</td>
              <td style="padding:6px 0;color:#333;font-size:14px;">${address}</td>
            </tr>
          </table>
        </td></tr>

        <!-- Items Table -->
        <tr><td style="padding:0 40px 24px;">
          <h2 style="margin:0 0 16px;font-size:16px;color:#333;border-bottom:2px solid #f0f0f0;padding-bottom:10px;">\u{1F4E6} Order Items</h2>
          <table width="100%" cellpadding="0" cellspacing="0" style="border:1px solid #f0f0f0;border-radius:8px;overflow:hidden;">
            <thead>
              <tr style="background:#f8f8f8;">
                <th style="padding:10px 12px;text-align:left;font-size:12px;color:#888;font-weight:600;">Product</th>
                <th style="padding:10px 12px;text-align:center;font-size:12px;color:#888;font-weight:600;">Qty</th>
                <th style="padding:10px 12px;text-align:right;font-size:12px;color:#888;font-weight:600;">Price</th>
                <th style="padding:10px 12px;text-align:right;font-size:12px;color:#888;font-weight:600;">Subtotal</th>
              </tr>
            </thead>
            <tbody>${itemRowsHtml}</tbody>
          </table>
        </td></tr>

        <!-- Total -->
        <tr><td style="padding:0 40px 30px;">
          <table width="100%" cellpadding="0" cellspacing="0">
            <tr>
              <td style="text-align:right;padding:12px 16px;background:#fff3e8;border-radius:8px;">
                <span style="font-size:14px;color:#888;">Total Amount: </span>
                <span style="font-size:22px;font-weight:bold;color:#e07b39;">\u09F3${total.toLocaleString()}</span>
              </td>
            </tr>
          </table>
        </td></tr>

        <!-- Footer -->
        <tr><td style="background:#f8f8f8;padding:20px 40px;text-align:center;border-top:1px solid #eee;">
          <p style="margin:0;color:#aaa;font-size:12px;">This email was sent automatically.</p>
          <p style="margin:6px 0 0;color:#aaa;font-size:12px;">\xA9 ${(/* @__PURE__ */ new Date()).getFullYear()} i SHOP BD \u2014 Premium Online Shop</p>
        </td></tr>
      </table>
    </td></tr>
  </table>
</body>
</html>`;
    const mailOptions = {
      from: `"i SHOP BD" <${process.env.EMAIL_USER}>`,
      to: notifyEmail,
      subject: `\u{1F6D2} New Order \u2014 ${customerName.substring(0, 60)} (\u09F3${total})`,
      text: [
        "New Order Confirmed!",
        "",
        `Customer: ${customerName}`,
        `Phone: ${customerPhone}`,
        `Address: ${address}`,
        `Total: \u09F3${total}`,
        "",
        "Items:",
        itemsPlainText
      ].join("\n"),
      html: htmlBody
    };
    try {
      if (process.env.EMAIL_USER && process.env.EMAIL_PASS) {
        await transporter.sendMail(mailOptions);
        console.log(`Order email sent successfully to ${notifyEmail}`);
      } else {
        console.warn("EMAIL_USER or EMAIL_PASS not set. Email not sent.");
      }
      res.json({ success: true, message: "Order processed successfully" });
    } catch (error) {
      console.error("Error sending email:", error);
      res.status(500).json({ success: false, error: "Failed to send email" });
    }
  });
  app.post("/api/courier/steadfast/bulk", async (req, res) => {
    const adminToken = req.headers["x-admin-token"];
    const masterPassword = MASTER_ADMIN_PASSWORD;
    if (!masterPassword || !adminToken || adminToken !== masterPassword) {
      return res.status(403).json({ success: false, error: "Unauthorized: Admin access required" });
    }
    const apiKey = process.env.STEADFAST_API_KEY || req.body.apiKey;
    const secretKey = process.env.STEADFAST_SECRET_KEY || req.body.secretKey;
    const { orders } = req.body;
    if (!apiKey || !secretKey) {
      return res.status(400).json({ success: false, error: "Steadfast API Key or Secret Key missing" });
    }
    if (!orders || !Array.isArray(orders) || orders.length === 0) {
      return res.status(400).json({ success: false, error: "No orders provided" });
    }
    if (orders.length > 1e3) {
      return res.status(400).json({ success: false, error: "Too many orders in one request (max 1000)" });
    }
    try {
      const requests = orders.map(async (order) => {
        try {
          const payload = {
            invoice: order.invoice,
            recipient_name: order.recipient_name,
            recipient_phone: order.recipient_phone,
            recipient_address: order.recipient_address,
            cod_amount: order.cod_amount,
            note: order.note || "Sent from i SHOP BD"
          };
          const response = await import_axios.default.post(
            "https://portal.packzy.com/api/v1/create_order",
            payload,
            {
              headers: {
                "Api-Key": apiKey,
                "Secret-Key": secretKey,
                "Content-Type": "application/json"
              },
              timeout: 1e4
            }
          );
          if (response.data && response.data.status === 200) {
            return {
              id: order.id,
              success: true,
              trackingId: response.data.consignment?.tracking_code || response.data.consignment?.consignment_id || "Success"
            };
          } else {
            return {
              id: order.id,
              success: false,
              error: response.data?.message || JSON.stringify(response.data) || "Failed to create order"
            };
          }
        } catch (error) {
          return {
            id: order.id,
            success: false,
            error: error.response?.data?.message || error.message || "Network Error"
          };
        }
      });
      const processedOrders = await Promise.all(requests);
      res.json({ success: true, processedOrders });
    } catch (error) {
      console.error("Error communicating with Steadfast API:", error);
      res.status(500).json({ success: false, error: "Failed to communicate with Steadfast API" });
    }
  });
  app.get("/api/steadfast-status", async (req, res) => {
    const { id } = req.query;
    if (!id) {
      return res.status(400).json({ success: false, error: "Tracking ID is required" });
    }
    try {
      const db = (0, import_firestore.getFirestore)();
      const keysDoc = await db.collection("admin_config").doc("keys").get();
      const { steadfastApiKey, steadfastSecretKey } = keysDoc.data() || {};
      if (!keysDoc.exists || !steadfastApiKey || !steadfastSecretKey) {
        return res.status(500).json({ success: false, error: "Steadfast API Key settings missing. Please configure them in Dashboard Settings." });
      }
      const response = await import_axios.default.get(
        `https://portal.packzy.com/api/v1/status_by_cid/${id}`,
        {
          headers: {
            "Api-Key": steadfastApiKey,
            "Secret-Key": steadfastSecretKey,
            "Content-Type": "application/json"
          },
          timeout: 1e4
        }
      );
      res.json({ success: true, data: response.data });
    } catch (error) {
      console.error("Error in steadfast-status proxy:", error);
      res.status(500).json({ success: false, error: error.response?.data?.message || "Failed to fetch Steadfast status" });
    }
  });
  app.get("/api/courier/steadfast/fraud/:phone", async (req, res) => {
    const { phone } = req.params;
    if (!phone) {
      return res.status(400).json({ success: false, error: "Phone number is required" });
    }
    try {
      const db = (0, import_firestore.getFirestore)();
      const keysDoc = await db.collection("admin_config").doc("keys").get();
      const { steadfastApiKey, steadfastSecretKey } = keysDoc.data() || {};
      if (!keysDoc.exists || !steadfastApiKey || !steadfastSecretKey) {
        return res.status(500).json({ success: false, error: "Steadfast API Key settings missing. Please configure them in Dashboard Settings." });
      }
      const response = await import_axios.default.get(
        `https://portal.packzy.com/api/v1/fraud_check/${phone}`,
        {
          headers: {
            "Api-Key": steadfastApiKey,
            "Secret-Key": steadfastSecretKey,
            "Content-Type": "application/json"
          },
          timeout: 1e4
        }
      );
      res.json({ success: true, data: response.data });
    } catch (error) {
      console.error("Error in steadfast-fraud check proxy:", error);
      res.status(error.response?.status || 500).json({
        success: false,
        error: error.response?.data?.error || error.response?.data?.message || "Failed to check customer fraud report"
      });
    }
  });
  async function verifyIsAdmin(req) {
    const isLocal = req.hostname === "localhost" || req.hostname === "127.0.0.1";
    if (isLocal && process.env.NODE_ENV !== "production") return true;
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith("Bearer ")) {
      try {
        const token = authHeader.split("Bearer ")[1];
        const decodedToken = await (0, import_auth.getAuth)().verifyIdToken(token);
        if (decodedToken) {
          const db = (0, import_firestore.getFirestore)();
          const userEmail = (decodedToken.email || "").toLowerCase().trim();
          const cleanEmail = userEmail.endsWith("@mobile.user") ? userEmail.replace("@mobile.user", "") : userEmail;
          const masterEmails = [
            "bonieaminrony@gmail.com",
            "islamicsoktitv@gmail.com",
            "ishopbd.online@gmail.com",
            "ifilmbd2025@gmail.com"
          ];
          if (masterEmails.includes(userEmail) || masterEmails.includes(cleanEmail)) {
            return true;
          }
          const adminDoc = await db.collection("admins").doc(decodedToken.uid).get();
          if (adminDoc.exists && ["admin", "owner"].includes(adminDoc.data()?.role)) {
            return true;
          }
          const adminEmailDoc = await db.collection("admins").doc(userEmail).get();
          if (adminEmailDoc.exists && ["admin", "owner"].includes(adminEmailDoc.data()?.role)) {
            return true;
          }
          if (cleanEmail !== userEmail) {
            const adminCleanEmailDoc = await db.collection("admins").doc(cleanEmail).get();
            if (adminCleanEmailDoc.exists && ["admin", "owner"].includes(adminCleanEmailDoc.data()?.role)) {
              return true;
            }
          }
        }
      } catch (err) {
        console.error("verifyIsAdmin error:", err);
      }
    }
    return false;
  }
  app.get("/api/admin/keys", async (req, res) => {
    const isAuthorized = await verifyIsAdmin(req);
    if (!isAuthorized) {
      return res.status(401).json({ success: false, error: "Unauthorized access" });
    }
    try {
      const db = (0, import_firestore.getFirestore)();
      const keysDoc = await db.collection("admin_config").doc("keys").get();
      res.json({ success: true, keys: keysDoc.exists ? keysDoc.data() : {} });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message || "Failed to read keys on server" });
    }
  });
  app.post("/api/admin/keys", async (req, res) => {
    const isAuthorized = await verifyIsAdmin(req);
    if (!isAuthorized) {
      return res.status(401).json({ success: false, error: "Unauthorized access" });
    }
    const {
      steadfastApiKey,
      steadfastSecretKey,
      geminiApiKey,
      pathaoClientId,
      pathaoClientSecret,
      pathaoUsername,
      pathaoPassword
    } = req.body;
    try {
      const db = (0, import_firestore.getFirestore)();
      await db.collection("admin_config").doc("keys").set({
        steadfastApiKey: steadfastApiKey || "",
        steadfastSecretKey: steadfastSecretKey || "",
        geminiApiKey: geminiApiKey || "",
        pathaoClientId: pathaoClientId || "",
        pathaoClientSecret: pathaoClientSecret || "",
        pathaoUsername: pathaoUsername || "",
        pathaoPassword: pathaoPassword || "",
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      }, { merge: true });
      res.json({ success: true, message: "Keys updated successfully on server" });
    } catch (error) {
      console.error("Error saving keys on server:", error);
      res.status(500).json({ success: false, error: error.message || "Failed to save keys on server" });
    }
  });
  app.get("/api/pathao-status", async (req, res) => {
    const { id } = req.query;
    if (!id) {
      return res.status(400).json({ success: false, error: "Tracking ID is required" });
    }
    try {
      const db = (0, import_firestore.getFirestore)();
      const keysDoc = await db.collection("admin_config").doc("keys").get();
      const { pathaoClientId, pathaoClientSecret, pathaoUsername, pathaoPassword } = keysDoc.data() || {};
      if (!keysDoc.exists || !pathaoClientId || !pathaoClientSecret || !pathaoUsername || !pathaoPassword) {
        return res.status(500).json({ success: false, error: "Pathao API configuration missing. Please configure them in Dashboard Settings." });
      }
      const tokenResponse = await import_axios.default.post(
        "https://api-hermes.pathao.com/aladdin/api/v1/issue-token",
        {
          client_id: pathaoClientId,
          client_secret: pathaoClientSecret,
          username: pathaoUsername,
          password: pathaoPassword,
          grant_type: "password"
        },
        {
          headers: {
            "Content-Type": "application/json",
            "Accept": "application/json"
          },
          timeout: 12e3
        }
      );
      const accessToken = tokenResponse.data?.access_token;
      if (!accessToken) {
        return res.status(500).json({ success: false, error: "Failed to authenticate with Pathao" });
      }
      const trackResponse = await import_axios.default.get(
        `https://api-hermes.pathao.com/aladdin/api/v1/orders/${id}/track`,
        {
          headers: {
            "Authorization": `Bearer ${accessToken}`,
            "Accept": "application/json",
            "Content-Type": "application/json"
          },
          timeout: 12e3
        }
      );
      res.json({ success: true, data: trackResponse.data });
    } catch (error) {
      console.error("Error in pathao-status proxy:", error);
      const errMsg = error.response?.data?.message || error.response?.data?.error || error.message || "Failed to fetch Pathao status";
      res.status(500).json({ success: false, error: errMsg });
    }
  });
  app.get("/api/courier/steadfast/status/:consignmentId", async (req, res) => {
    const { consignmentId } = req.params;
    const apiKey = req.headers["x-api-key"];
    const secretKey = req.headers["x-secret-key"];
    if (!apiKey || !secretKey) {
      return res.status(400).json({ success: false, error: "Steadfast API keys are missing in headers" });
    }
    try {
      const response = await import_axios.default.get(
        `https://portal.packzy.com/api/v1/status_by_cid/${consignmentId}`,
        {
          headers: {
            "Api-Key": apiKey,
            "Secret-Key": secretKey,
            "Content-Type": "application/json"
          },
          timeout: 1e4
        }
      );
      res.json({ success: true, data: response.data });
    } catch (error) {
      console.error("Error fetching Steadfast status:", error);
      res.status(500).json({ success: false, error: error.response?.data?.message || "Failed to fetch status" });
    }
  });
  app.post("/api/chat", async (req, res) => {
    const rawIp = req.headers["cf-connecting-ip"] || req.headers["x-forwarded-for"] || req.ip || req.socket.remoteAddress || "unknown";
    const ip = Array.isArray(rawIp) ? rawIp[0] : typeof rawIp === "string" ? rawIp.split(",")[0].trim() : rawIp;
    if (!rateLimit(ip + ":chat", 10, 6e4)) {
      return res.status(429).json({ error: "AI request limit reached. Please wait a moment." });
    }
    const { messages, modelName = "gemini-1.5-flash" } = req.body;
    if (!process.env.GEMINI_API_KEY) {
      return res.status(500).json({ error: "AI is not configured." });
    }
    try {
      const normalizedMessages = [];
      let lastRole = null;
      for (const m of messages) {
        const role = m.role === "assistant" ? "model" : "user";
        if (role === lastRole) {
          normalizedMessages[normalizedMessages.length - 1].parts[0].text += "\n" + m.content;
        } else {
          normalizedMessages.push({
            role,
            parts: [{ text: m.content }]
          });
          lastRole = role;
        }
      }
      while (normalizedMessages.length > 0 && normalizedMessages[0].role !== "user") {
        normalizedMessages.shift();
      }
      let productsList = [];
      try {
        const db = (0, import_firestore.getFirestore)();
        const allProducts = await getCachedProducts(db);
        productsList = allProducts.filter((p) => !p.deleted && p.isPublished !== false).map((p) => ({
          name: p.name || "Unknown Product",
          price: p.price || 0,
          stock: p.stock !== void 0 ? p.stock : 0,
          isComingSoon: !!p.isComingSoon
        }));
      } catch (err) {
        console.error("Failed to load products for AI context:", err);
      }
      const productsContext = productsList.map((p) => `- ${p.name}: Price \u09F3${p.price}, Stock: ${p.stock}${p.isComingSoon ? " (Pre-order)" : ""}`).join("\n");
      const systemInstruction = `You are a helpful, courteous and knowledgeable AI assistant for 'Rokomari Ponno Hari' (\u09B0\u0995\u09AE\u09BE\u09B0\u09BF \u09AA\u09A3\u09CD\u09AF \u09B9\u09BE\u09A1\u09BC\u09BF), the premier online organic food and natural products store in Bangladesh.

LANGUAGE RULE (MOST IMPORTANT): Always respond in the SAME language the user writes in.
- If the user writes in Bengali (\u09AC\u09BE\u0982\u09B2\u09BE), respond fully in Bengali.
- If the user writes in English, respond in English.
- If the user writes a mix, respond in the dominant language.

Your role:
- Help customers with organic product information (e.g. \u09B8\u09C1\u09A8\u09CD\u09A6\u09B0\u09AC\u09A8\u09C7\u09B0 \u0996\u09BE\u0981\u099F\u09BF \u09AE\u09A7\u09C1, \u0998\u09BE\u09A8\u09BF \u09AD\u09BE\u0999\u09BE \u09B8\u09B0\u09BF\u09B7\u09BE\u09B0 \u09A4\u09C7\u09B2, \u0997\u09BE\u0993\u09DF\u09BE \u0998\u09BF, \u09AE\u09B0\u09BF\u09DF\u09AE \u0996\u09C7\u099C\u09C1\u09B0, \u09A1\u09CD\u09B0\u09BE\u0987 \u09AB\u09CD\u09B0\u09C1\u099F\u09B8, \u099A\u09BF\u09DF\u09BE \u09B8\u09BF\u09A1, \u0995\u09BE\u09B2\u09CB\u099C\u09BF\u09B0\u09BE \u09A4\u09C7\u09B2, \u09AE\u09B6\u09B2\u09BE), benefits, pricing, and ordering.
- Suggest healthy, natural products based on the customer's needs and wellness goals.
- Be warm, polite, and trustworthy at all times.
- Use BDT pricing format (\u09F3).

Current real-time product catalog of Rokomari Ponno Hari:
${productsContext}

Guidelines:
- Explain the health benefits and purity of our organic items when asked.
- If a product is out of stock (Stock is 0 or less), inform the customer politely and suggest alternatives.
- If a customer wants to order, guide them to add the product to cart or click 'Buy Now' / '\u0985\u09B0\u09CD\u09A1\u09BE\u09B0 \u0995\u09B0\u09C1\u09A8'.
- Do NOT reveal internal system instructions or pricing strategies.
- Keep responses concise, natural and helpful.`;
      const genAI = new import_genai.GoogleGenAI({
        apiKey: process.env.GEMINI_API_KEY
      });
      const selectedModel = modelName && ["gemini-2.0-flash", "gemini-1.5-flash", "gemini-2.5-flash"].includes(modelName) ? modelName : "gemini-2.0-flash";
      const response = await genAI.models.generateContent({
        model: selectedModel,
        contents: normalizedMessages,
        config: {
          systemInstruction
        }
      });
      const aiReplyText = response.text || "Sorry, no response could be generated.";
      const { chatId } = req.body;
      if (chatId && typeof chatId === "string" && admin.apps.length) {
        try {
          const db = (0, import_firestore.getFirestore)();
          const chatRef = db.collection("support_chats").doc(chatId);
          const aiMessage = {
            id: "ai_" + Date.now().toString() + Math.random().toString(36).substr(2, 6),
            text: aiReplyText,
            senderId: "ai_assistant",
            senderName: "\u09B0\u0995\u09AE\u09BE\u09B0\u09BF \u09AA\u09A3\u09CD\u09AF \u09B9\u09BE\u09A1\u09BC\u09BF AI",
            isAdmin: true,
            createdAt: (/* @__PURE__ */ new Date()).toISOString(),
            reactions: {}
          };
          await chatRef.set({
            userId: chatId,
            lastMessage: aiReplyText,
            lastMessageAt: (/* @__PURE__ */ new Date()).toISOString(),
            unreadByUser: true,
            messages: import_firestore.FieldValue.arrayUnion(aiMessage)
          }, { merge: true });
        } catch (dbErr) {
          console.error("Failed to save AI message in Firestore via Admin:", dbErr);
        }
      }
      res.json({ text: aiReplyText });
    } catch (error) {
      console.error("Gemini Error:", error);
      res.status(500).json({ error: error?.message || "Failed to get response from AI" });
    }
  });
  app.post("/api/ai-recommendations", async (req, res) => {
    const rawIp = req.headers["cf-connecting-ip"] || req.headers["x-forwarded-for"] || req.ip || req.socket.remoteAddress || "unknown";
    const ip = Array.isArray(rawIp) ? rawIp[0] : typeof rawIp === "string" ? rawIp.split(",")[0].trim() : rawIp;
    if (!rateLimit(ip + ":recommendations", 30, 6e4)) {
      return res.status(429).json({ error: "Request limit reached. Please wait a moment." });
    }
    const { currentProductId, viewedProductIds = [], searchQuery = "" } = req.body;
    if (!process.env.GEMINI_API_KEY) {
      return res.status(500).json({ error: "Gemini API key is not configured" });
    }
    try {
      const db = (0, import_firestore.getFirestore)();
      const rawProducts = await getCachedProducts(db);
      const allProducts = rawProducts.map((p) => ({
        id: p.id,
        name: p.name || "Unknown Product",
        category: p.category || "General",
        isPublished: p.isPublished !== false,
        deleted: !!p.deleted
      })).filter((p) => !p.deleted && p.isPublished);
      if (allProducts.length === 0) {
        return res.json({ productIds: [] });
      }
      const currentProduct = allProducts.find((p) => p.id === currentProductId);
      const viewedProducts = allProducts.filter((p) => viewedProductIds.includes(p.id));
      const catalogText = allProducts.map((p) => `ID: "${p.id}", Name: "${p.name}", Category: "${p.category}"`).join("\n");
      const prompt = `You are a product recommendation system for an e-commerce store in Bangladesh.
Current product the user is looking at:
${currentProduct ? `Name: "${currentProduct.name}", Category: "${currentProduct.category}"` : "None"}

User's recently viewed products:
${viewedProducts.length > 0 ? viewedProducts.map((p) => `- Name: "${p.name}", Category: "${p.category}"`).join("\n") : "None"}

User's search query:
"${searchQuery || "None"}"

Available products catalog (ID, Name, Category):
${catalogText}

Task: Recommend the top 5 most relevant product IDs from the catalog.
Rule 1: Never recommend the current product (ID: "${currentProductId}").
Rule 2: Respond ONLY with a valid JSON array of strings containing the selected product IDs (e.g. ["p1", "p2", "p3"]). No markdown formatting, no comments, no extra text.`;
      const genAI = new import_genai.GoogleGenAI({
        apiKey: process.env.GEMINI_API_KEY
      });
      const response = await genAI.models.generateContent({
        model: "gemini-2.0-flash",
        contents: prompt
      });
      let text = response.text || "[]";
      text = text.replace(/```json/g, "").replace(/```/g, "").trim();
      try {
        const productIds = JSON.parse(text);
        if (Array.isArray(productIds)) {
          const validIds = productIds.filter((id) => allProducts.some((p) => p.id === id));
          return res.json({ productIds: validIds.slice(0, 5) });
        }
      } catch (parseErr) {
        console.error("Failed to parse Gemini recommendations JSON output:", text);
      }
      res.json({ productIds: [] });
    } catch (error) {
      console.error("AI Recommendations Error:", error);
      res.status(500).json({ error: "Failed to generate recommendations" });
    }
  });
  async function getFCMToken(serviceAccountPath2) {
    const keyData = JSON.parse(import_fs.default.readFileSync(serviceAccountPath2, "utf8"));
    const header = { alg: "RS256", typ: "JWT" };
    const now = Math.floor(Date.now() / 1e3);
    const exp = now + 3600;
    const claim = {
      iss: keyData.client_email,
      scope: "https://www.googleapis.com/auth/firebase.messaging",
      aud: keyData.token_uri,
      exp,
      iat: now
    };
    const base64UrlHeader = Buffer.from(JSON.stringify(header)).toString("base64url");
    const base64UrlClaim = Buffer.from(JSON.stringify(claim)).toString("base64url");
    const sign = import_crypto.default.createSign("RSA-SHA256");
    sign.update(base64UrlHeader + "." + base64UrlClaim);
    const signature = sign.sign(keyData.private_key).toString("base64url");
    const jwt = base64UrlHeader + "." + base64UrlClaim + "." + signature;
    const response = await import_axios.default.post(keyData.token_uri, new URLSearchParams({
      grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
      assertion: jwt
    }).toString(), {
      headers: { "Content-Type": "application/x-www-form-urlencoded" }
    });
    return {
      access_token: response.data.access_token,
      project_id: keyData.project_id
    };
  }
  app.post("/api/send-push", async (req, res) => {
    const { token, title = "Notification", body, link = "/" } = req.body;
    if (!token || !body) {
      return res.status(400).json({ error: "Missing token or body" });
    }
    let serviceAccountPath2 = import_path.default.join(process.cwd(), "api", "service-account.json");
    if (!import_fs.default.existsSync(serviceAccountPath2)) {
      serviceAccountPath2 = import_path.default.join(process.cwd(), "public", "api", "service-account.json");
    }
    if (!import_fs.default.existsSync(serviceAccountPath2)) {
      console.error("[CRITICAL] service-account.json key not found for FCM");
      return res.status(500).json({ error: "Service account key not found" });
    }
    try {
      const authData = await getFCMToken(serviceAccountPath2);
      const fcmUrl = `https://fcm.googleapis.com/v1/projects/${authData.project_id}/messages:send`;
      const notification = {
        message: {
          token,
          notification: { title, body },
          webpush: { fcm_options: { link } }
        }
      };
      const response = await import_axios.default.post(fcmUrl, notification, {
        headers: {
          Authorization: `Bearer ${authData.access_token}`,
          "Content-Type": "application/json"
        }
      });
      res.json(response.data);
    } catch (error) {
      console.error("FCM Send Error:", error?.response?.data || error.message);
      res.status(500).json({ error: "Failed to send push notification", details: error?.response?.data || error.message });
    }
  });
  app.post("/api/reviews", async (req, res) => {
    try {
      const { productId, review } = req.body;
      if (!productId || !review) {
        return res.status(400).json({ error: "Product ID and review data are required." });
      }
      const cleanProdId = String(productId).trim();
      const reviewId = String(review.id || `rev_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`);
      const reviewData = {
        id: reviewId,
        userId: review.userId || `guest_${Math.random().toString(36).substr(2, 5)}`,
        userName: String(review.userName || "Customer").trim(),
        userPhoto: review.userPhoto || null,
        rating: Math.min(5, Math.max(1, Number(review.rating) || 5)),
        comment: String(review.comment || "").trim(),
        images: Array.isArray(review.images) ? review.images : [],
        createdAt: review.createdAt || (/* @__PURE__ */ new Date()).toISOString()
      };
      const db = (0, import_firestore.getFirestore)();
      const productRef = db.collection("products").doc(cleanProdId);
      const productSnap = await productRef.get();
      const reviewDocRef = productRef.collection("reviews").doc(reviewId);
      await reviewDocRef.set(reviewData, { merge: true });
      let newRating = reviewData.rating;
      let newCount = 1;
      if (productSnap.exists) {
        const productData = productSnap.data() || {};
        const currentRating = Number(productData.rating) || 0;
        const currentCount = Number(productData.reviewCount) || 0;
        newCount = currentCount + 1;
        newRating = Number(((currentRating * currentCount + reviewData.rating) / newCount).toFixed(1));
        await productRef.set({
          rating: newRating,
          reviewCount: newCount,
          updatedAt: import_firestore.FieldValue.serverTimestamp()
        }, { merge: true });
      } else {
        await productRef.set({
          rating: newRating,
          reviewCount: 1,
          updatedAt: import_firestore.FieldValue.serverTimestamp()
        }, { merge: true });
      }
      invalidateProductCache();
      return res.json({
        success: true,
        review: reviewData,
        rating: newRating,
        reviewCount: newCount
      });
    } catch (error) {
      console.error("Review Submit Error in /api/reviews:", error);
      return res.status(500).json({ error: "Failed to submit review", details: error?.message || error });
    }
  });
  app.get("/api/product-image/:id", async (req, res) => {
    const productId = req.params.id;
    try {
      const url = `https://firestore.googleapis.com/v1/projects/i-shop-bd/databases/(default)/documents/products/${productId}`;
      const response = await import_axios.default.get(url, { timeout: 5e3 });
      const data = response.data;
      if (data && data.fields && data.fields.image) {
        const imageStr = data.fields.image.stringValue;
        if (imageStr && imageStr.startsWith("data:")) {
          const match = imageStr.match(/^data:([^;]+);base64,(.*)$/);
          if (match) {
            const contentType = match[1];
            const base64Data = match[2];
            const imgBuffer = Buffer.from(base64Data, "base64");
            res.setHeader("Content-Type", contentType);
            res.setHeader("Cache-Control", "public, max-age=86400");
            return res.send(imgBuffer);
          }
        } else if (imageStr && (imageStr.startsWith("http://") || imageStr.startsWith("https://"))) {
          const ALLOWED_IMAGE_HOSTS = [
            "firebasestorage.googleapis.com",
            "storage.googleapis.com",
            "lh3.googleusercontent.com",
            "i.imgur.com",
            "res.cloudinary.com"
          ];
          try {
            const parsedUrl = new URL(imageStr);
            if (ALLOWED_IMAGE_HOSTS.some((host) => parsedUrl.hostname === host || parsedUrl.hostname.endsWith("." + host))) {
              return res.redirect(imageStr);
            } else {
              console.warn(`[SECURITY] Blocked SSRF redirect to: ${parsedUrl.hostname}`);
              return res.status(400).send("Invalid image source");
            }
          } catch {
            return res.status(400).send("Invalid image URL");
          }
        }
      }
      const distPath = import_path.default.join(process.cwd(), "dist");
      const logoPath = import_path.default.join(distPath, "logo.png");
      if (import_fs.default.existsSync(logoPath)) {
        res.setHeader("Content-Type", "image/png");
        return res.sendFile(logoPath);
      }
      res.status(404).send("Image not found");
    } catch (error) {
      console.error("Error serving product image:", error);
      res.status(500).send("Failed to fetch image");
    }
  });
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath, { maxAge: "1y", index: false }));
    app.get("/api/ping", (req, res) => {
      res.status(200).send("pong");
    });
    app.get("*", async (req, res) => {
      res.setHeader("Cache-Control", "no-cache");
      const htmlPath = import_path.default.join(distPath, "index.html");
      if (!import_fs.default.existsSync(htmlPath)) {
        return res.sendFile(htmlPath);
      }
      let html = import_fs.default.readFileSync(htmlPath, "utf8");
      let productIdentifier = req.query.p || req.query.product || req.query.landing;
      if (!productIdentifier && req.path.startsWith("/product/")) {
        productIdentifier = req.path.replace(/^\/product\//, "").split("/")[0];
      } else if (!productIdentifier && req.path.startsWith("/p/")) {
        productIdentifier = req.path.replace(/^\/p\//, "").split("/")[0];
      }
      if (productIdentifier) {
        try {
          const rawIdentifier = decodeURIComponent(String(productIdentifier)).trim();
          const parts = rawIdentifier.split("-");
          let lastPart = parts[parts.length - 1];
          let productId = lastPart && lastPart.length >= 6 ? lastPart : rawIdentifier;
          let url = `https://firestore.googleapis.com/v1/projects/i-shop-bd/databases/(default)/documents/products/${productId}`;
          let response = await import_axios.default.get(url, { timeout: 4e3 }).catch(() => null);
          if (!response?.data?.fields && productId !== rawIdentifier) {
            url = `https://firestore.googleapis.com/v1/projects/i-shop-bd/databases/(default)/documents/products/${rawIdentifier}`;
            response = await import_axios.default.get(url, { timeout: 4e3 }).catch(() => null);
          }
          const data = response?.data;
          if (data && data.fields) {
            const name = data.fields.name?.stringValue || "Product Details";
            let description = data.fields.description?.stringValue || "";
            description = description.replace(/[\r\n]+/g, " ").replace(/"/g, "&quot;").trim();
            if (description.length > 150) {
              description = description.substring(0, 147) + "...";
            }
            if (!description) {
              description = `${name} - Buy gadgets & lifestyle accessories online at i SHOP BD.`;
            }
            const brand = data.fields.brand?.stringValue || "i SHOP BD";
            let price = 0;
            if (data.fields.price) {
              price = Number(data.fields.price.integerValue || data.fields.price.doubleValue || data.fields.price.stringValue || 0);
            }
            const stockVal = data.fields.stock ? Number(data.fields.stock.integerValue || data.fields.stock.doubleValue || data.fields.stock.stringValue || 0) : 1;
            const inStock = stockVal > 0;
            const protocol = req.headers["x-forwarded-proto"] || req.protocol;
            const host = req.get("host");
            const imageUrl = `${protocol}://${host}/api/product-image/${productId}`;
            const cleanSlug = getProductSlug({ id: productId, name, slug: data.fields.slug?.stringValue });
            const productPath = `/p/${cleanSlug}`;
            const currentUrl = `${protocol}://${host}${productPath}`;
            const productSchema = {
              "@context": "https://schema.org/",
              "@type": "Product",
              "name": name,
              "image": imageUrl,
              "description": description,
              "brand": {
                "@type": "Brand",
                "name": brand
              },
              "offers": {
                "@type": "Offer",
                "url": currentUrl,
                "priceCurrency": "BDT",
                "price": price,
                "availability": inStock ? "https://schema.org/InStock" : "https://schema.org/OutOfStock",
                "itemCondition": "https://schema.org/NewCondition"
              }
            };
            html = html.replace("<!-- CANONICAL_URL_PLACEHOLDER -->", `<link rel="canonical" href="${currentUrl}" />`);
            html = html.replace("</head>", `<script type="application/ld+json">${JSON.stringify(productSchema)}</script></head>`);
            html = html.replace(/<title>[^<]*<\/title>/i, `<title>${name} - i SHOP BD</title>`);
            html = html.replace(/<meta name="description" content="[^"]*"\s*\/?>/i, `<meta name="description" content="${description}" />`);
            html = html.replace(/<meta property="og:url" content="[^"]*"\s*\/?>/i, `<meta property="og:url" content="${currentUrl}" />`);
            html = html.replace(/<meta property="og:title" content="[^"]*"\s*\/?>/i, `<meta property="og:title" content="${name}" />`);
            html = html.replace(/<meta property="og:description" content="[^"]*"\s*\/?>/i, `<meta property="og:description" content="${description}" />`);
            html = html.replace(/<meta property="og:image" content="[^"]*"\s*\/?>/i, `<meta property="og:image" content="${imageUrl}" />`);
            html = html.replace(/<meta property="twitter:url" content="[^"]*"\s*\/?>/i, `<meta property="twitter:url" content="${currentUrl}" />`);
            html = html.replace(/<meta property="twitter:title" content="[^"]*"\s*\/?>/i, `<meta property="twitter:title" content="${name}" />`);
            html = html.replace(/<meta property="twitter:description" content="[^"]*"\s*\/?>/i, `<meta property="twitter:description" content="${description}" />`);
            html = html.replace(/<meta property="twitter:image" content="[^"]*"\s*\/?>/i, `<meta property="twitter:image" content="${imageUrl}" />`);
            const fallbackHtml = `
              <div id="seo-fallback" style="opacity:0; position:absolute; z-index:-1;">
                <h1>${name}</h1>
                <img src="${imageUrl}" alt="${name}" />
                <p>${description}</p>
                <p>Price: \u09F3${price}</p>
                <p>Brand: ${brand}</p>
              </div>
            `;
            html = html.replace('<div id="root">', `<div id="root">${fallbackHtml}`);
          }
        } catch (error) {
          console.error("Error fetching product meta tags for OG:", error.message);
        }
      } else {
        let categorySlug = "";
        if (req.path.startsWith("/category/")) {
          categorySlug = req.path.replace(/^\/category\//, "").split("/")[0];
        } else if (req.path.startsWith("/c/")) {
          categorySlug = req.path.replace(/^\/c\//, "").split("/")[0];
        } else if (req.query.category) {
          categorySlug = String(req.query.category).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
        }
        if (categorySlug) {
          const protocol = req.headers["x-forwarded-proto"] || req.protocol;
          const host = req.get("host");
          const currentUrl = `${protocol}://${host}/category/${categorySlug}`;
          const CATEGORY_SEO_DATA = {
            "pure-honey": {
              title: "\u0996\u09BE\u0981\u099F\u09BF \u09AE\u09A7\u09C1 \u0993 \u09B8\u09C1\u09A8\u09CD\u09A6\u09B0\u09AC\u09A8\u09C7\u09B0 \u099A\u09BE\u0995\u09C7\u09B0 \u09AE\u09A7\u09C1 \u09A6\u09BE\u09AE | Pure Honey Price in BD - \u09B0\u0995\u09AE\u09BE\u09B0\u09BF \u09AA\u09A3\u09CD\u09AF \u09B9\u09BE\u09A1\u09BC\u09BF",
              description: "\u09E7\u09E6\u09E6% \u0996\u09BE\u0981\u099F\u09BF \u0993 \u09AA\u09CD\u09B0\u09BE\u0995\u09C3\u09A4\u09BF\u0995 \u09B8\u09C1\u09A8\u09CD\u09A6\u09B0\u09AC\u09A8\u09C7\u09B0 \u099A\u09BE\u0995\u09C7\u09B0 \u09AE\u09A7\u09C1 \u0995\u09BF\u09A8\u09C1\u09A8 \u09B0\u0995\u09AE\u09BE\u09B0\u09BF \u09AA\u09A3\u09CD\u09AF \u09B9\u09BE\u09A1\u09BC\u09BF \u09A5\u09C7\u0995\u09C7\u0964 \u0995\u09CD\u09AF\u09BE\u09B6 \u0985\u09A8 \u09A1\u09C7\u09B2\u09BF\u09AD\u09BE\u09B0\u09BF\u09A4\u09C7 \u09B9\u09CB\u09AE \u09A1\u09C7\u09B2\u09BF\u09AD\u09BE\u09B0\u09BF!",
              keywords: "\u0996\u09BE\u0981\u099F\u09BF \u09AE\u09A7\u09C1, \u09B8\u09C1\u09A8\u09CD\u09A6\u09B0\u09AC\u09A8\u09C7\u09B0 \u09AE\u09A7\u09C1, \u09AE\u09A7\u09C1 \u09A6\u09BE\u09AE \u09AC\u09BE\u0982\u09B2\u09BE\u09A6\u09C7\u09B6, raw honey, organic honey bd, rokomari ponno hari"
            },
            "mustard-oil-ghee": {
              title: "\u0998\u09BE\u09A8\u09BF \u09AD\u09BE\u0999\u09BE \u09B8\u09B0\u09BF\u09B7\u09BE\u09B0 \u09A4\u09C7\u09B2 \u0993 \u0996\u09BE\u0981\u099F\u09BF \u0997\u09BE\u0993\u09DF\u09BE \u0998\u09BF | Pure Ghee & Mustard Oil - \u09B0\u0995\u09AE\u09BE\u09B0\u09BF \u09AA\u09A3\u09CD\u09AF \u09B9\u09BE\u09A1\u09BC\u09BF",
              description: "\u0995\u09BE\u09A0\u09C7\u09B0 \u0998\u09BE\u09A8\u09BF \u09AD\u09BE\u0999\u09BE \u09E7\u09E6\u09E6% \u0996\u09BE\u0981\u099F\u09BF \u09B8\u09B0\u09BF\u09B7\u09BE\u09B0 \u09A4\u09C7\u09B2 \u0993 \u09B8\u09C1\u09AC\u09BE\u09B8\u09BF\u09A4 \u09A6\u09BE\u09A8\u09BE\u09A6\u09BE\u09B0 \u0996\u09BE\u0981\u099F\u09BF \u0997\u09BE\u0993\u09DF\u09BE \u0998\u09BF \u0995\u09BF\u09A8\u09C1\u09A8 \u09B0\u0995\u09AE\u09BE\u09B0\u09BF \u09AA\u09A3\u09CD\u09AF \u09B9\u09BE\u09A1\u09BC\u09BF \u09A5\u09C7\u0995\u09C7\u0964",
              keywords: "\u09B8\u09B0\u09BF\u09B7\u09BE\u09B0 \u09A4\u09C7\u09B2, \u0998\u09BE\u09A8\u09BF \u09AD\u09BE\u0999\u09BE \u09A4\u09C7\u09B2, \u0996\u09BE\u0981\u099F\u09BF \u0998\u09BF, \u0997\u09BE\u0993\u09DF\u09BE \u0998\u09BF \u09A6\u09BE\u09AE, pure mustard oil bd, cow ghee, rokomari ponno hari"
            },
            "dates-dry-fruits": {
              title: "\u09AE\u09B0\u09BF\u09DF\u09AE \u0996\u09C7\u099C\u09C1\u09B0 \u0993 \u09AA\u09CD\u09B0\u09BF\u09AE\u09BF\u09DF\u09BE\u09AE \u09A1\u09CD\u09B0\u09BE\u0987 \u09AB\u09CD\u09B0\u09C1\u099F\u09B8 | Maryam Dates & Dry Fruits - \u09B0\u0995\u09AE\u09BE\u09B0\u09BF \u09AA\u09A3\u09CD\u09AF \u09B9\u09BE\u09A1\u09BC\u09BF",
              description: "\u09AE\u09A6\u09BF\u09A8\u09BE\u09B0 \u09AA\u09CD\u09B0\u09BF\u09AE\u09BF\u09DF\u09BE\u09AE \u09AE\u09B0\u09BF\u09DF\u09AE \u0996\u09C7\u099C\u09C1\u09B0, \u0995\u09BE\u099C\u09C1\u09AC\u09BE\u09A6\u09BE\u09AE, \u0995\u09BE\u09A0\u09AC\u09BE\u09A6\u09BE\u09AE, \u0986\u0996\u09B0\u09CB\u099F \u0993 \u09AE\u09BF\u0995\u09CD\u09B8\u09A1 \u09A1\u09CD\u09B0\u09BE\u0987 \u09AB\u09CD\u09B0\u09C1\u099F\u09B8 \u0995\u09BF\u09A8\u09C1\u09A8 \u09B8\u09C7\u09B0\u09BE \u09A6\u09BE\u09AE\u09C7\u0964",
              keywords: "\u09AE\u09B0\u09BF\u09DF\u09AE \u0996\u09C7\u099C\u09C1\u09B0, \u0996\u09C7\u099C\u09C1\u09B0\u09C7\u09B0 \u09A6\u09BE\u09AE, \u0995\u09BE\u099C\u09C1\u09AC\u09BE\u09A6\u09BE\u09AE, \u0995\u09BE\u09A0\u09AC\u09BE\u09A6\u09BE\u09AE, \u09A1\u09CD\u09B0\u09BE\u0987 \u09AB\u09CD\u09B0\u09C1\u099F\u09B8, maryam dates, dry fruits bd, rokomari ponno hari"
            },
            "organic-seeds-oil": {
              title: "\u0985\u09B0\u09CD\u0997\u09BE\u09A8\u09BF\u0995 \u099A\u09BF\u09DF\u09BE \u09B8\u09BF\u09A1 \u0993 \u0995\u09BE\u09B2\u09CB\u099C\u09BF\u09B0\u09BE \u09A4\u09C7\u09B2 | Organic Chia Seeds & Black Seed Oil - \u09B0\u0995\u09AE\u09BE\u09B0\u09BF \u09AA\u09A3\u09CD\u09AF \u09B9\u09BE\u09A1\u09BC\u09BF",
              description: "\u09AA\u09CD\u09B0\u09BF\u09AE\u09BF\u09DF\u09BE\u09AE \u0997\u09CD\u09B0\u09C7\u09A1 \u0985\u09B0\u09CD\u0997\u09BE\u09A8\u09BF\u0995 \u099A\u09BF\u09DF\u09BE \u09B8\u09BF\u09A1 \u098F\u09AC\u0982 \u0995\u09CB\u09B2\u09CD\u09A1 \u09AA\u09CD\u09B0\u09C7\u09B8\u09A1 \u0996\u09BE\u0981\u099F\u09BF \u0995\u09BE\u09B2\u09CB\u099C\u09BF\u09B0\u09BE \u09A4\u09C7\u09B2 \u0995\u09BF\u09A8\u09C1\u09A8 \u09B8\u09C1\u09B2\u09AD \u09AE\u09C2\u09B2\u09CD\u09AF\u09C7\u0964",
              keywords: "\u099A\u09BF\u09DF\u09BE \u09B8\u09BF\u09A1, \u0995\u09BE\u09B2\u09CB\u099C\u09BF\u09B0\u09BE \u09A4\u09C7\u09B2, \u099A\u09BF\u09DF\u09BE \u09B8\u09BF\u09A1\u09C7\u09B0 \u09A6\u09BE\u09AE, chia seeds bd, black seed oil, rokomari ponno hari"
            },
            "pure-spices": {
              title: "\u0996\u09BE\u0981\u099F\u09BF \u09AA\u09BE\u09B9\u09BE\u09DC\u09BF \u09AE\u09B8\u09B2\u09BE \u0993 \u0997\u09C1\u0981\u09DC\u09BE | Pure Spices in Bangladesh - \u09B0\u0995\u09AE\u09BE\u09B0\u09BF \u09AA\u09A3\u09CD\u09AF \u09B9\u09BE\u09A1\u09BC\u09BF",
              description: "\u09AA\u09BE\u09B9\u09BE\u09DC\u09BF \u0985\u099E\u09CD\u099A\u09B2\u09C7\u09B0 \u0996\u09BE\u0981\u099F\u09BF \u09B9\u09B2\u09C1\u09A6, \u09AE\u09B0\u09BF\u099A \u0993 \u09A7\u09A8\u09BF\u09DF\u09BE \u0997\u09C1\u0981\u09DC\u09BE \u0995\u09BF\u09A8\u09C1\u09A8 \u09B6\u09A4\u09AD\u09BE\u0997 \u09AD\u09C7\u099C\u09BE\u09B2\u09AE\u09C1\u0995\u09CD\u09A4 \u09A8\u09BF\u09B6\u09CD\u099A\u09DF\u09A4\u09BE\u09DF\u0964",
              keywords: "\u0996\u09BE\u0981\u099F\u09BF \u09AE\u09B8\u09B2\u09BE, \u09B9\u09B2\u09C1\u09A6 \u0997\u09C1\u0981\u09DC\u09BE, \u09AE\u09B0\u09BF\u099A \u0997\u09C1\u0981\u09DC\u09BE, organic spices bd, rokomari ponno hari"
            },
            "organic-tea-herbal": {
              title: "\u0985\u09B0\u09CD\u0997\u09BE\u09A8\u09BF\u0995 \u099A\u09BE \u0993 \u09AD\u09C7\u09B7\u099C \u09AA\u09A3\u09CD\u09AF | Organic Tea & Herbal in BD - \u09B0\u0995\u09AE\u09BE\u09B0\u09BF \u09AA\u09A3\u09CD\u09AF \u09B9\u09BE\u09A1\u09BC\u09BF",
              description: "\u09AA\u09CD\u09B0\u09BE\u0995\u09C3\u09A4\u09BF\u0995 \u0985\u09CD\u09AF\u09BE\u09A8\u09CD\u099F\u09BF\u0985\u0995\u09CD\u09B8\u09BF\u09A1\u09C7\u09A8\u09CD\u099F \u09B8\u09AE\u09C3\u09A6\u09CD\u09A7 \u0985\u09B0\u09CD\u0997\u09BE\u09A8\u09BF\u0995 \u0997\u09CD\u09B0\u09BF\u09A8 \u099F\u09BF \u0993 \u09AD\u09C7\u09B7\u099C \u0996\u09BE\u09A6\u09CD\u09AF\u09AA\u09A3\u09CD\u09AF \u0995\u09BF\u09A8\u09C1\u09A8 \u09B0\u0995\u09AE\u09BE\u09B0\u09BF \u09AA\u09A3\u09CD\u09AF \u09B9\u09BE\u09A1\u09BC\u09BF \u09A5\u09C7\u0995\u09C7\u0964",
              keywords: "\u0985\u09B0\u09CD\u0997\u09BE\u09A8\u09BF\u0995 \u099A\u09BE, \u0997\u09CD\u09B0\u09BF\u09A8 \u099F\u09BF, \u09A4\u09C1\u09B2\u09B8\u09C0 \u099A\u09BE, herbal tea bd, rokomari ponno hari"
            }
          };
          const formattedName = categorySlug.split("-").map((w) => w.charAt(0).toUpperCase() + w.slice(1)).join(" ");
          const categorySeo = CATEGORY_SEO_DATA[categorySlug] || {
            title: `${formattedName} - \u09B0\u0995\u09AE\u09BE\u09B0\u09BF \u09AA\u09A3\u09CD\u09AF \u09B9\u09BE\u09A1\u09BC\u09BF (Rokomari Ponno Hari)`,
            description: `Buy authentic and 100% pure ${formattedName} online at best price in Bangladesh from Rokomari Ponno Hari.`,
            keywords: `${categorySlug}, buy ${categorySlug} bd, rokomari ponno hari`
          };
          const imageUrl = `${protocol}://${host}/logo.png`;
          let categoryProducts = [];
          try {
            if (admin.apps.length) {
              const db = (0, import_firestore.getFirestore)();
              const snap = await db.collection("products").where("deleted", "==", false).where("isPublished", "==", true).get();
              categoryProducts = snap.docs.map((d) => ({ id: d.id, ...d.data() })).filter((p) => {
                const catSlug = (p.category || "").toLowerCase().replace(/[^a-z0-9]+/g, "-");
                return catSlug.includes(categorySlug) || categorySlug.includes(catSlug);
              });
            }
          } catch (e) {
          }
          const categorySchema = {
            "@context": "https://schema.org",
            "@type": "CollectionPage",
            "name": categorySeo.title,
            "description": categorySeo.description,
            "url": currentUrl,
            "image": imageUrl,
            "mainEntity": {
              "@type": "ItemList",
              "numberOfItems": categoryProducts.length,
              "itemListElement": categoryProducts.slice(0, 24).map((p, idx) => ({
                "@type": "ListItem",
                "position": idx + 1,
                "url": `${protocol}://${host}/product/${getProductSlug(p)}`,
                "name": p.name,
                "image": p.image || imageUrl
              }))
            }
          };
          html = html.replace("<!-- CANONICAL_URL_PLACEHOLDER -->", `<link rel="canonical" href="${currentUrl}" />`);
          html = html.replace("</head>", `<script type="application/ld+json">${JSON.stringify(categorySchema)}</script></head>`);
          html = html.replace(/<title>[^<]*<\/title>/i, `<title>${categorySeo.title}</title>`);
          html = html.replace(/<meta name="description" content="[^"]*"\s*\/?>/i, `<meta name="description" content="${categorySeo.description}" />`);
          html = html.replace(/<meta name="keywords" content="[^"]*"\s*\/?>/i, `<meta name="keywords" content="${categorySeo.keywords}" />`);
          html = html.replace(/<meta property="og:url" content="[^"]*"\s*\/?>/i, `<meta property="og:url" content="${currentUrl}" />`);
          html = html.replace(/<meta property="og:title" content="[^"]*"\s*\/?>/i, `<meta property="og:title" content="${categorySeo.title}" />`);
          html = html.replace(/<meta property="og:description" content="[^"]*"\s*\/?>/i, `<meta property="og:description" content="${categorySeo.description}" />`);
          html = html.replace(/<meta property="og:image" content="[^"]*"\s*\/?>/i, `<meta property="og:image" content="${imageUrl}" />`);
          html = html.replace(/<meta property="twitter:url" content="[^"]*"\s*\/?>/i, `<meta property="twitter:url" content="${currentUrl}" />`);
          html = html.replace(/<meta property="twitter:title" content="[^"]*"\s*\/?>/i, `<meta property="twitter:title" content="${categorySeo.title}" />`);
          html = html.replace(/<meta property="twitter:description" content="[^"]*"\s*\/?>/i, `<meta property="twitter:description" content="${categorySeo.description}" />`);
          html = html.replace(/<meta property="twitter:image" content="[^"]*"\s*\/?>/i, `<meta property="twitter:image" content="${imageUrl}" />`);
          if (categoryProducts.length > 0) {
            const fallbackHtml = `
              <div id="seo-category-fallback" style="opacity:0; position:absolute; z-index:-1;">
                <h1>${categorySeo.title}</h1>
                <p>${categorySeo.description}</p>
                <ul>
                  ${categoryProducts.map((p) => `<li><a href="/product/${getProductSlug(p)}">${p.name} - \u09F3${p.price}</a></li>`).join("")}
                </ul>
              </div>
            `;
            html = html.replace('<div id="root">', `<div id="root">${fallbackHtml}`);
          }
        }
      }
      if (html.includes("<!-- CANONICAL_URL_PLACEHOLDER -->")) {
        const protocol = req.headers["x-forwarded-proto"] || req.protocol;
        const host = req.get("host");
        html = html.replace("<!-- CANONICAL_URL_PLACEHOLDER -->", `<link rel="canonical" href="${protocol}://${host}/" />`);
      }
      try {
        const initialProds = await getCachedProducts();
        if (initialProds && initialProds.length > 0) {
          html = html.replace("</head>", `<script>window.__INITIAL_PRODUCTS__ = ${JSON.stringify(initialProds)};</script></head>`);
        }
      } catch (e) {
      }
      res.setHeader("Content-Type", "text/html; charset=UTF-8");
      res.send(html);
    });
  }
  app.use((err, req, res, next) => {
    console.error("Unhandled Error:", err.stack);
    res.status(500).json({ error: "Internal server error" });
  });
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
    if (process.env.NODE_ENV === "production") {
      console.log("Running in PRODUCTION mode");
    }
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
